import os
import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Si pas d'interface graphique, utiliser un backend non interactif
if os.environ.get('DISPLAY', '') == '':
    matplotlib.use('Agg')  # backend non interactif
    DISPLAY_MODE = False
else:
    DISPLAY_MODE = True

# Charger les données
file_path = 'nb_variable_utilisateurs/scenario6/rx_throughput.csv'
data = pd.read_csv(file_path, sep=';')

# Définir la plage horaire totale à traiter
data = data[(data['time'] >= 20.0) & (data['time'] <= 7000.0)]

# Rééchantillonnage (pas de 0.5 seconde)
def resample_data(data, step=0.1):
    data = data.copy()
    data['time'] = (data['time'] // step) * step
    resampled_data = data.groupby('time')['throughput (kbps)'].mean().reset_index()
    return resampled_data

data = resample_data(data, step=0.1)

# Création des lag features
def create_lag_features(data, lag=10):
    df = data.copy()
    for i in range(1, lag + 1):
        df[f'lag_{i}'] = df['throughput (kbps)'].shift(i)
    df.dropna(inplace=True)
    return df

lag_data = create_lag_features(data, lag=10)

# Découper les données
observation_data = lag_data[lag_data['time'] <= 1000.0]
prediction_data = lag_data[lag_data['time'] > 1000.0]

# Features et cibles
X_obs = observation_data.drop(['time', 'throughput (kbps)'], axis=1)
y_obs = observation_data['throughput (kbps)']
X_pred = prediction_data.drop(['time', 'throughput (kbps)'], axis=1)
y_pred_true = prediction_data['throughput (kbps)']

# Mise à l’échelle
scaler = StandardScaler()
X_obs_scaled = scaler.fit_transform(X_obs)
X_pred_scaled = scaler.transform(X_pred)

# Entraînement SVR RBF
model = SVR(kernel='rbf', C=100, gamma='scale', epsilon=0.1)
model.fit(X_obs_scaled, y_obs)

# Prédiction
y_predicted = model.predict(X_pred_scaled)

# Évaluation
mse = mean_squared_error(y_pred_true, y_predicted)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_pred_true, y_predicted)
r2 = r2_score(y_pred_true, y_predicted)

print(f"MSE: {mse:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"MAE: {mae:.2f}")
print(f"R²: {r2:.2f}")

# Affichage de la prédiction sur une plage donnée
display_start_time = 800.0
display_end_time = 1200.0

obs_display = observation_data[(observation_data['time'] >= display_start_time) &
                               (observation_data['time'] <= display_end_time)]

pred_display = prediction_data[(prediction_data['time'] >= display_start_time) &
                               (prediction_data['time'] <= display_end_time)]

pred_indices = pred_display.index - prediction_data.index[0]

# Tracé
plt.figure(figsize=(12, 6))

if not obs_display.empty:
    plt.plot(obs_display['time'], obs_display['throughput (kbps)'],
             label="Valeurs réelles (20s–1000s)", color='blue')

if not pred_display.empty:
    plt.plot(pred_display['time'], pred_display['throughput (kbps)'],
             label="Valeurs réelles (>1000s)", color='green')
    plt.plot(pred_display['time'], y_predicted[pred_indices],
             label="Prédictions SVR", color='red', linestyle='--')

plt.xlabel("Temps (s)")
plt.ylabel("Throughput (kbps)")
plt.title(f"Prédiction SVR RBF ({display_start_time}s à {display_end_time}s)")
plt.legend()
plt.grid(True)
plt.tight_layout()

# Affichage ou sauvegarde selon le mode
plt.savefig("svr_RBF_1_prediction.png")
