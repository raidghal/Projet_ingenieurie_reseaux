import pandas as pd
import numpy as np
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt

# Charger les données
file_path = 'nb_variable_utilisateurs/scenario1/tx_throughput.csv'
data = pd.read_csv(file_path, sep=';')

# Filtrage temporel
data = data[(data['time'] >= 20.0) & (data['time'] <= 7000.0)]

# Rééchantillonnage
def resample_data(data, step=0.1):
    data = data.copy()
    data['time'] = (data['time'] // step) * step
    return data.groupby('time')['throughput (kbps)'].mean().reset_index()

data = resample_data(data, step=0.1)

# Création efficace des lag features
def create_lag_features(data, lag):
    base = data[['time', 'throughput (kbps)']].copy()
    lagged = [data['throughput (kbps)'].shift(i).rename(f'lag_{i}') for i in range(1, lag + 1)]
    return pd.concat([base] + lagged, axis=1).dropna()

# Paramètres
display_start_time = 500.0
display_end_time = 1500.0
lags_to_test = [1, 10, 100]
colors = ['red', 'green', 'orange']

# Plot
plt.figure(figsize=(12, 6))

for lag, color in zip(lags_to_test, colors):
    df = create_lag_features(data, lag)

    # Séparer observation/prédiction
    observation_data = df[df['time'] <= 1000.0]
    prediction_data = df[df['time'] > 1000.0]

    if prediction_data.empty:
        print(f"[!] Aucune donnée de prédiction pour lag={lag}")
        continue

    X_obs = observation_data.drop(['time', 'throughput (kbps)'], axis=1)
    y_obs = observation_data['throughput (kbps)']
    X_pred = prediction_data.drop(['time', 'throughput (kbps)'], axis=1)
    y_pred_true = prediction_data['throughput (kbps)']

    # Normalisation
    scaler = StandardScaler()
    X_obs_scaled = scaler.fit_transform(X_obs)
    X_pred_scaled = scaler.transform(X_pred)

    # SVR
    model = SVR(kernel='rbf', C=100, gamma='scale', epsilon=0.1)
    model.fit(X_obs_scaled, y_obs)
    y_predicted = model.predict(X_pred_scaled)

    # Affichage dans plage demandée
    pred_display = prediction_data[(prediction_data['time'] >= display_start_time) &
                                   (prediction_data['time'] <= display_end_time)]

    if pred_display.empty:
        print(f"[!] Aucune donnée à afficher pour lag={lag}")
        continue

    # Alignement des indices avec .iloc
    start_idx = pred_display.index[0] - prediction_data.index[0]
    end_idx = start_idx + len(pred_display)

    plt.plot(pred_display['time'], y_predicted[start_idx:end_idx],
             label=f'Prédiction SVR (lag={lag})', linestyle='--', linewidth=2, color=color)

    # Afficher les scores
    mse = mean_squared_error(y_pred_true, y_predicted)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_pred_true, y_predicted)
    r2 = r2_score(y_pred_true, y_predicted)

    # Affichage formaté
    print(f"Lag = {lag:<4} | MSE = {mse:.2f} | RMSE = {rmse:.2f} | MAE = {mae:.2f} | R² = {r2:.4f}")

# Tracer les valeurs réelles (échantillonnées pour lisibilité)
ground_truth = df[(df['time'] >= display_start_time) & (df['time'] <= display_end_time)]
gt_sampled = ground_truth.iloc[::10]
plt.plot(gt_sampled['time'], gt_sampled['throughput (kbps)'],
         label='Valeurs réelles (échantillonnées)', color='blue', linewidth=1)

# Mise en forme du graphique
plt.xlabel("Temps (s)")
plt.ylabel("Throughput (kbps)")
plt.title(f"Comparaison des prédictions SVR pour différents lags ({display_start_time}s à {display_end_time}s)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("svr_RBF_prediction.png")
